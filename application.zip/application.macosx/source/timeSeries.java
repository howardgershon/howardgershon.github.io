import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class timeSeries extends PApplet {

// full dataset
FloatTable data;

float dataMin, dataMax;

float plotX1, plotY1;
float plotX2, plotY2;
float labelX, labelY;
ColorIntegrator[] colors;

int currentColumn = 0;
int pastCol;
int columnCount;
int rowCount;
int selection;
float buttonX;
float buttonY;
float buttonWidth;
float buttonHeight;
float[] vs = new float[rowCount];


//ColorIntegrator colors = new ColorIntegrator;
int[] clrs = new int[4];
//colors = [#FF0000, #C800FF, #0000FF, #5679C1];
//chroma[1] = #C800FF;
//chroma[2] = #0000FF;
//chroma[3] = #5679C1;

int yearMin, yearMax;
int[] years;

PFont plotFont;
PFont yearFont;
PFont volFont;
PFont axisFont;
PFont titleFont;

Integrator[][] interpolators;
Integrator[][] regInter;

int yearInterval = 10;
int volumeInterval = 10;
int volumeIntervalMinor = 5;
int barWidth = 4;

float[] tabLeft, tabRight;
float tabTop, tabBottom;
float tabPad = 10;

boolean overButton;
boolean buttonOver;
boolean pressed;

// setup loop (runs once)
public void setup() {
  size(720, 405);
  
  clrs[0] = 0xffFF0000;
  clrs[1] = 0xffC800FF;
  clrs[2] = 0xff0000FF;
  clrs[3] = 0xff5679C1;
  
  colors = new ColorIntegrator[4];
  for (int x = 0; x < clrs.length; x++) {
    colors[x] = new ColorIntegrator(clrs[3]);
  }
  
  selection = 1;
  currentColumn = 3;

  overButton = false;
  buttonOver = false;
  pressed = false;
  
  setCurrent(0);
  
  // import data
  data = new FloatTable("./data/milk-tea-coffee.tsv");
  columnCount = data.getColumnCount();
  rowCount = data.getRowCount();
  
  years = PApplet.parseInt(data.getRowNames());
  yearMin = years [0];
  yearMax = years[years.length - 1];
  
  currentColumn = 0;
  
  interpolators = new Integrator[columnCount][rowCount];
  for (int col = 0; col < columnCount; col++){
    for (int row = 0; row < rowCount; row++) {
      float initialValue = data.getFloat(row, 0);
      interpolators[col][row] = new Integrator(initialValue);
      //interpolators[row].attraction = 0.1;  // Set lower than the default
    }
  }
  
  regInter = new Integrator[columnCount][rowCount];
 
  vs = regression(0);
  for (int col = 0; col < columnCount; col++) {
    for (int row = 0; row < rowCount; row++) {
      float initialValue = vs[row];
      regInter[col][row] = new Integrator(initialValue);
    }
  }
  
  selection = 1;
  currentColumn = 0;

  // assign data variables
  dataMin = 0;
  dataMax = ceil(data.getTableMax() / volumeInterval) * volumeInterval;
  
  //Corners of the plotted time series
  plotX1 = 120;
  plotX2 = width - 80;
  labelX = 50;
  plotY1 = 60;
  plotY2 = height - 70;
  labelY = height - 25;
    
  buttonWidth = 160;
  buttonHeight = 30;
  
  buttonX = plotX2 - buttonWidth;
  buttonY = plotY1 - 40;

  plotFont = createFont("SansSerif", 20);
  textFont(plotFont);
  smooth();
  //println(PFont.list());
}


// draw loop (runs infinitely)
public void draw() {
  update(mouseX, mouseY);
  // background color (light-grey)
  background(224);
  
  frameRate(120);
  
  // show the plot area as a white box
  fill(255);
  rectMode(CORNERS);
  noStroke();
  rect(plotX1, plotY1, plotX2, plotY2);
  
  if (pressed) {
    fill(0xff0000FF);
  } else {
    fill(0xff82D7FB);
  }
  rectMode(CORNER);
  rect(buttonX, buttonY, buttonWidth, buttonHeight);
  
  if (pressed) {
    fill(0xffFFFFFF);
  } else {
    fill(0xff000000);
  }
  textAlign(CENTER);
  if (pressed) {
    text("Unregress", buttonX + buttonWidth/2, buttonY + 20);
  } else {
    text("Regress", buttonX + buttonWidth/2, buttonY + 20);
  } 
  //drawTitle();
  rectMode(CORNERS);
  drawAxisLabels();
  
  drawYearLabels();
  drawVolumeLabels();
  
  for (int col = 0; col < columnCount; col++) {
    for (int row = 0; row < rowCount; row++) {
      interpolators[col][row].update();
    }
  }
  
  for (int col = 0; col < columnCount; col++) {
    for (int row = 0; row < rowCount; row++) {
      regInter[col][row].update();
    }
  }
  
  for (int col = 0; col < columnCount; col++) {
    colors[col].update();
  }
  
//  strokeWeight(5);
//  // draw the data for the first column
//  stroke(#5679C1);
//  noFill();
//  strokeWeight(2);
  //drawDataHighlight(currentColumn, iterploators[currentColumn]);
  //drawDataPoints(currentColumn);
  int c = color(0xff5679C1);
  if (pastCol != 3) {
    if (currentColumn == 3) {
      for(int col = 0; col < columnCount; col++){
          drawDataHighlight(currentColumn, interpolators[col]);
      }     
      drawSummary(selection, interpolators);
    } else {
      drawDataHighlight(currentColumn, interpolators[currentColumn]);
      drawData(currentColumn, selection, colors[3]._value, interpolators[currentColumn]);
    }
  } else {
    if (currentColumn == 3) {
      for(int col = 0; col < columnCount; col++){
          drawDataHighlight(currentColumn, interpolators[col]);
      }     
      drawSummary(selection, interpolators);
    } else {
      for(int col = 0; col < columnCount; col++){
        drawDataHighlight(currentColumn, interpolators[currentColumn]);
        //System.out.println(colors[0]._value);
        drawData(currentColumn, selection, colors[3]._value, interpolators[col]);
      }
    }
  }
    
  drawTitleTabs();
  //noFill();
  //drawDataLine(currentColumn);
  
  if(pressed){
     if (pastCol == 3){
      if(currentColumn == 3) {
        for (int col = 0; col < columnCount; col++){
          colors[col].target(clrs[col]);
          drawRegression(col, colors[col]._value, regInter[col]);
        }
      } else {
        colors[3].target(clrs[3]);
        drawRegression(currentColumn, colors[3]._value, regInter[currentColumn]);
      }
    } else {
      if(currentColumn == 3) {
        for (int col = 0; col < columnCount; col++){
          colors[col].target(clrs[col]);
          drawRegression(col, colors[col]._value, regInter[col]);
        }
      } else {
        colors[3].target(clrs[3]);
        drawRegression(currentColumn, colors[3]._value, regInter[currentColumn]);
      }
    }
  }
  
}

//**********************************************************************//
//**********************************************************************//
//**                                                                  **//
//**                       Design Methods                             **//
//**                                                                  **//
//**********************************************************************//
//**********************************************************************//

public void update(int x, int y) {
  if ( overButton(buttonX, buttonY, buttonWidth, buttonHeight) ) {
    buttonOver = true;
  } else {
    buttonOver = false;
  }
}

public boolean overButton (float x, float y, float width, float height) {
  if (mouseX >= x && mouseX <= x+width && 
      mouseY >= y && mouseY <= y+height) {
    return true;
  } else {
    return false;
  }
}

public void keyPressed() {
  if (key == '[') {
     currentColumn--;
     if (currentColumn < 0) {
       currentColumn= columnCount - 1;
       System.out.println(currentColumn);
     }
  } else if (key == ']') {
    currentColumn++;
    if (currentColumn == columnCount) {
      currentColumn = 0;
    }
  } else if (key == '1') {
    selection = 1;
  } else if (key == '2') {
    selection = 2;
  } else if (key == '3') { 
    selection = 3;
  } else if (key == '4') {
    selection = 4;
  } else if (key == '5') {
    selection = 5;
  }
  setCurrent(currentColumn);
  
}

//void drawTitle() {
//
//  // Draw the title of the current plot.
//  fill(0);
//  textSize(20);
//  textAlign(LEFT);
//  titleFont = createFont("Georgia", 30);
//  textFont(titleFont);
//  String title = data.getColumnName(currentColumn);
//  text(title, plotX1, plotY1 - 10);
//
//}

public void drawAxisLabels() {
  fill(0);
  textSize(13);
  textLeading(15);
  axisFont = createFont("Verdana", 13);
  textFont(axisFont);
  
  float x = labelX;
  float y = (plotY1 + plotY2)/2;
  
  textAlign(CENTER, CENTER);
  //Use \n (aca enter or linefeed) to break the text into separate lines.
  pushMatrix();
  translate(x,y);
  rotate(-HALF_PI);
  
  text("Gallons consumed\nper capita", 0, 0);
  popMatrix();
  textAlign(CENTER);
  text("Year", (plotX1+plotX2)/2, labelY);
}

public void drawYearLabels() {
  fill(0);
  textSize(10);
  textAlign(CENTER, TOP);
  yearFont = createFont("Georgia", 10);
  textFont(yearFont);
  int rowCount = data.getRowCount();
  
  //Use thin, gray lines to draw the grid.
  stroke(224);
  strokeWeight(1);
  
  for (int row = 0; row < rowCount; row++) {
    if (years[row] % yearInterval == 0) {
      float x = map(years[row], yearMin, yearMax, plotX1, plotX2);
      text(years[row], x, plotY2 + 10);
      line(x, plotY1, x, plotY2);
    }
  }
}

public void drawVolumeLabels() {
  fill(0);
  textSize(10);
  //textAlign(RIGHT, CENTER);
  stroke(128);
  strokeWeight(1);
  volFont = createFont("Georgia", 10);
  textFont(volFont);
  
  for (float v = dataMin; v <= dataMax; v += volumeIntervalMinor) {
    if (v % volumeIntervalMinor == 0){
      float y = map(v, dataMin, dataMax, plotY2, plotY1);
      if (v % volumeInterval == 0) {
        if (v == dataMin) {
          textAlign(RIGHT);
        } else if (v == dataMax) {
          textAlign(RIGHT, TOP);
        } else {
          textAlign(RIGHT, CENTER);
        } 
        text(floor(v), plotX1 - 10, y);
        line(plotX1 - 4, y, plotX1, y);
      } else {
        line(plotX1 - 2, y, plotX1, y);
      }
    }
  }
}

public void drawTitleTabs() {
  rectMode(CORNERS);
  noStroke();
  textSize(20);
  textAlign(LEFT);

  // On first use of this method, allocate space for an array
  // to store the values for the left and right edges of the tabs
  if (tabLeft == null) {
    tabLeft = new float[columnCount + 1];
    tabRight = new float[columnCount + 1];
  }
  
  float runningX = plotX1; 
  tabTop = plotY1 - textAscent() - 15;
  tabBottom = plotY1;
  
  for (int col = 0; col < columnCount; col++) {
    String title = data.getColumnName(col);
    tabLeft[col] = runningX; 
    float titleWidth = textWidth(title);
    tabRight[col] = tabLeft[col] + tabPad + titleWidth + tabPad;
    
    // If the current tab, set its background white, otherwise use pale gray
    fill(col == currentColumn ? 255 : 224);
    rect(tabLeft[col], tabTop, tabRight[col], tabBottom);
    //System.out.println(tabRight[col]);
    // If the current tab, use black for the text, otherwise use dark gray
    fill(col == currentColumn ? 0 : 64);
    text(title, runningX + tabPad, plotY1 - 10);
    
    runningX = tabRight[col];
  }
  //summary tab
  String title = "Summary";
  tabLeft[3] = runningX;
  float titleWidth = textWidth(title);
  tabRight[3] = tabLeft[3] + tabPad + titleWidth + tabPad;
  fill(224);
  rect(tabLeft[3], tabTop, tabRight[3], tabBottom);
  fill(64);
  text(title, runningX + tabPad, plotY1 - 10);
  if (currentColumn == 3){
  // If the current tab, set its background white, the others will be color coded
    
    fill(255);
    rect(tabLeft[3], tabTop, tabRight[3], tabBottom);
    fill(0);
    text(title, runningX + tabPad, plotY1 - 10);
    runningX = plotX1;
    for(int cl = 0; cl < columnCount; cl++){    
        fill(colors[cl]._value);
        rect(tabLeft[cl], tabTop, tabRight[cl], tabBottom);
        fill(255);
        String colTitle = data.getColumnName(cl);
        text(colTitle, runningX + tabPad, plotY1 - 10);
        runningX = tabRight[cl];
      }
  }
  
  }


public void mousePressed() {
  if (mouseY > tabTop && mouseY < tabBottom) {
    for (int col = 0; col < columnCount+1; col++) {
      if (mouseX > tabLeft[col] && mouseX < tabRight[col]) {
        setCurrent(col);
        //System.out.println(col);
      }
    }
  }
  
  if (buttonOver) {
    pressed = !pressed;
  }
}

public void setColumn(int col){
  if (col != currentColumn){
    currentColumn = col;
    //System.out.println(col);
  }
}

public void setCurrent(int col) {
  pastCol = currentColumn;
  currentColumn = col;
  if (pastCol != 3){
    if (currentColumn == 3){
      for (int cll = 0; cll < columnCount; cll++){
        for (int row = 0; row < rowCount; row++) {
          float initialValue = data.getFloat(row, pastCol);
          interpolators[cll][row] = new Integrator(initialValue);
          //interpolators[row].attraction = 0.1;  // Set lower than the default
        }
        int init = clrs[pastCol];
        colors[cll] = new ColorIntegrator(init);
      }
      float[] v = regression(pastCol);
      for (int cl = 0; cl < columnCount; cl++) {
        for (int row = 0; row < rowCount; row++) {
          float initialValue = v[row];
          regInter[cl][row] = new Integrator(initialValue);
        }
      }
      
      
      
      for (int cl = 0; cl < columnCount; cl++) {
        for (int row = 0; row < rowCount; row++) {
          interpolators[cl][row].target(data.getFloat(row, cl));
          colors[cl].target(clrs[cl]);
          
          for (int x = 0; x < 10; x++) {
            interpolators[cl][row].update();
            colors[cl].update();
          }
        }
      }
      
      for (int cl = 0; cl < columnCount; cl++) {
        float[] vals = regression(col);
        for (int row = 0; row < rowCount; row++) {
          regInter[cl][row].target(vals[row]);
        }
      }
        
    } else {      
      for (int cl = 0; cl < columnCount; cl++) {
        for (int row = 0; row < rowCount; row++) {
          interpolators[cl][row].target(data.getFloat(row, currentColumn));
        }
      }
    }
    
    for (int cl = 0; cl < columnCount; cl++) {
        float[] vals = regression(col);
        for (int row = 0; row < rowCount; row++) {
          regInter[cl][row].target(vals[row]);
        }
      }
    
  } else {
    if (currentColumn == 3) {
       for (int cll = 0; cll < columnCount; cll++){
        for (int row = 0; row < rowCount; row++) {
          float initialValue = data.getFloat(row, cll);
          interpolators[cll][row] = new Integrator(initialValue);
          //interpolators[row].attraction = 0.1;  // Set lower than the default
        }
        int init = clrs[cll];
        colors[cll] = new ColorIntegrator(init);
      }
      
      for (int cl = 0; cl < columnCount; cl++) {
        for (int row = 0; row < rowCount; row++) {
          float initialValue = vs[row];
          regInter[cl][row] = new Integrator(initialValue);
        }
      }
      
      for (int cl = 0; cl < columnCount; cl++) {
        for (int row = 0; row < rowCount; row++) {
          interpolators[cl][row].target(data.getFloat(row, cl));
          for (int x = 0; x < 5; x++) {
            interpolators[cl][row].update();
            colors[cl].update();
          }
        }
      }
      
      for (int cl = 0; cl < columnCount; cl++) {
        float[] vals = regression(col);
        for (int row = 0; row < rowCount; row++) {
          regInter[cl][row].target(vals[row]);
        }
      }
      
    } else {
      //contracting
      for (int cll = 0; cll < columnCount; cll++){
        for (int row = 0; row < rowCount; row++) {
          float initialValue = data.getFloat(row, cll);
          interpolators[cll][row] = new Integrator(initialValue);
          //interpolators[row].attraction = 0.1;  // Set lower than the default
        }
        int init = clrs[cll];
        colors[cll] = new ColorIntegrator(init);
      }
      
      for (int cl = 0; cl < columnCount; cl++) {
        for (int row = 0; row < rowCount; row++) {
          float initialValue = vs[row];
          regInter[cl][row] = new Integrator(initialValue);
        }
      }
      
      for (int cl = 0; cl < columnCount; cl++) {
        for (int row = 0; row < rowCount; row++) {
          interpolators[cl][row].target(data.getFloat(row, currentColumn));
          colors[cl].target(clrs[cl]);
          
          for(int x = 0; x < 5; x++){
            interpolators[cl][row].update();
            //colors[cl].update();
          }
        }
      }
      
      for (int cl = 0; cl < columnCount; cl++) {
        float[] vals = regression(col);
        for (int row = 0; row < rowCount; row++) {
          regInter[cl][row].target(vals[row]);
        }
      }
    }
  }
}

//**********************************************************************//
//**********************************************************************//
//**                                                                  **//
//**                        Draw Methods                              **//
//**                                                                  **//
//**********************************************************************//
//**********************************************************************//


//Draw the data as a series of points.
public void drawDataPoints(int col, Integrator[] inter){
  int rowCount = data.getRowCount();
  for(int row = 0; row < rowCount; row++){
    if(data.isValid(row, col)) {
      //float value = data.getFloat(row, col);
      float value = inter[row]._value;
      float x = map(years[row], yearMin, yearMax, plotX1, plotX2);
      float y = map(value, dataMin, dataMax, plotY2, plotY1);
      point(x, y);
    } 
  }
}


public void drawDataLine(int col, Integrator[] inter) {
  beginShape();
  int rowCount = data.getRowCount();
  for (int row = 0; row < rowCount; row++) {
    if (data.isValid(row, col)) {
      //float value = data.getFloat(row, col);
      float value = inter[row]._value;
      float x = map(years[row], yearMin, yearMax, plotX1, plotX2);
      float y = map(value, dataMin, dataMax, plotY2, plotY1);
      vertex(x, y);
    }
  }
  endShape();
}

public void drawConnectedDotsLine(int col, Integrator[] inter) {
  stroke(color(0xff5679C1));
  strokeWeight(5);
  drawDataPoints(col, inter);
  noFill();
  strokeWeight(0.5f);
  drawDataLine(col, inter);
}

public void drawDataArea(int col, Integrator[] inter) {
  beginShape();
  for (int row = 0; row < rowCount; row++) {
    if (data.isValid(row, col)) {
      //float value = data.getFloat(row, col);
      float value = inter[row]._value;
      float x = map(years[row], yearMin, yearMax, plotX1, plotX2);
      float y = map(value, dataMin, dataMax, plotY2, plotY1);
      //vertex(x, y);
      
      curveVertex(x, y);
    }
  }
  vertex(plotX2, plotY2);
  vertex(plotX1, plotY2);
  endShape(CLOSE);
}

public void drawDataHighlight(int col, Integrator[] inter){
  for (int row = 0; row < rowCount; row++) {
    if (data.isValid(row, col)){
      //float value = data.getFloat(row, col);
      axisFont = createFont("Verdana", 13);
      textFont(axisFont);
      float value = inter[row]._value;
      float x = map(years[row], yearMin, yearMax, plotX1, plotX2);
      float y = map(value, dataMin, dataMax, plotY2, plotY1);
      if (dist(mouseX, mouseY, x, y) < 3){
        strokeWeight(5);
        point(x, y);
        //fill(0);
        noFill();
        textSize(10);
        textAlign(CENTER);
        text(nf(value, 0, 2) + "(" + years[row] + ")", x, y - 8);
      }
    }
  }
}

public void drawDataCurve(int col, Integrator[] inter){
  beginShape();
  for (int row = 0; row < rowCount; row++){
    if (data.isValid(row, col)) {
      //float value = data.getFloat(row, col);
      float value = inter[row]._value;
      float x = map(years[row], yearMin, yearMax, plotX1, plotX2);
      float y = map(value, dataMin, dataMax, plotY2, plotY1);

      curveVertex(x, y);
      if ((row == 0) || (row == rowCount -1)) {
        curveVertex(x, y);
      }
    }
  }
  endShape();
}

public void drawDataBars(int col, Integrator[] inter){
  for (int row = 0; row < rowCount; row++){
    if (data.isValid(row, col)) {
      //float value = data.getFloat(row, col);
      float value = inter[row]._value;
      float x = map(years[row], yearMin, yearMax, plotX1, plotX2);
      float y = map(value, dataMin, dataMax, plotY2, plotY1);
      rect(x - barWidth/2, y, x+barWidth/2, plotY2);
    }
  }
}

public void drawData(int col, int selection, int clr, Integrator[] inter){
  if (selection == 1){
    stroke(clr);
    strokeWeight(5);
    drawDataPoints(col, inter);
  } else if (selection == 2){
    drawConnectedDotsLine(col, inter);
  } else if (selection == 3){
    noFill();
    stroke(clr);
    strokeWeight(2);
    drawDataCurve(col, inter);
  } else if (selection == 4){
    noStroke();
    fill(clr);
    drawDataArea(col, inter);
    drawYearLabels();
  } else if (selection == 5){
    noStroke();
    fill(clr);
    drawDataBars(col, inter);
  }  
}

public void drawSummary(int selection, Integrator[][] inter){
 float[] min = new float[3];
 int[] order = new int[3];
 for (int cl = 0; cl < columnCount; cl++){
   min[cl] = data.getColumnMin(cl);
   //System.out.println(cl + ", " + min[cl]);
   order[cl] = cl;
 } 
 
 for (int i=0; i<min.length-1; i++) {
        for (int j=i+1; j<min.length; j++) {
            if (min[i] < min[j]) {
                //... Exchange elements
                float temp = min[i];
                int tempO = order[i];
                min[i] = min[j];
                order[i] = order[j];
                min[j] = temp;
                order[j] = tempO;
            }
        }
    }
 
 for (int cl = 0; cl < columnCount; cl++){
    Integrator[] integ = new Integrator[rowCount];
    int cll = order[cl];
    integ = inter[cll];
    colors[cl].target(clrs[cl]);
    drawDataHighlight(cll, integ);
    drawData(cll, selection, colors[cll]._value, integ); 
 }
  
}

public void drawRegression (int col, int clr, Integrator[] inter) {
  float[] vals = regression(col);

  stroke(clr);
  
  beginShape();
  for (int row = 0; row < rowCount; row++) {
      inter[row].target(vals[row]);
      for (int x = 0; x < 5; x++) {
        inter[row].update();
      }
      float x = map(years[row], yearMin, yearMax, plotX1, plotX2);
      float y = map(inter[row]._value, dataMin, dataMax, plotY2, plotY1);
      //System.out.println(x + ", " + y);
      vertex(x, y);
    }
  
  endShape();
 
}

public float[] regression (int col) {
  float[] vals = new float[rowCount];
  if (col == 0) {
    for (int x = 0; x < rowCount; x++) {
        vals[x] = 37.1031f - 0.1204f*x;
    } 
  } else if (col == 1) {
    for (int x = 0; x < rowCount; x++) {
        vals[x] = 7.3280f - 0.0055f*x;
    }
  } else if (col == 2) {
    for (int x = 0; x < rowCount; x++) {
        vals[x] = 33.8880f - 0.1405f*x;
    }
  }
  return vals;
}
// first line of the file should be the column headers
// first column should be the row titles
// all other values are expected to be floats
// getFloat(0, 0) returns the first data value in the upper lefthand corner
// files should be saved as "text, tab-delimited"
// empty rows are ignored
// extra whitespace is ignored


class FloatTable {
  int rowCount;
  int columnCount;
  float[][] data;
  String[] rowNames;
  String[] columnNames;
  
  
  FloatTable(String filename) {
    String[] rows = loadStrings(filename);
    
    String[] columns = split(rows[0], TAB);
    columnNames = subset(columns, 1); // upper-left corner ignored
    scrubQuotes(columnNames);
    columnCount = columnNames.length;

    rowNames = new String[rows.length-1];
    data = new float[rows.length-1][];

    // start reading at row 1, because the first row was only the column headers
    for (int i = 1; i < rows.length; i++) {
      if (trim(rows[i]).length() == 0) {
        continue; // skip empty rows
      }
      if (rows[i].startsWith("#")) {
        continue;  // skip comment lines
      }

      // split the row on the tabs
      String[] pieces = split(rows[i], TAB);
      scrubQuotes(pieces);
      
      // copy row title
      rowNames[rowCount] = pieces[0];
      // copy data into the table starting at pieces[1]
      data[rowCount] = parseFloat(subset(pieces, 1));

      // increment the number of valid rows found so far
      rowCount++;      
    }
    // resize the 'data' array as necessary
    data = (float[][]) subset(data, 0, rowCount);
  }
  
  
  public void scrubQuotes(String[] array) {
    for (int i = 0; i < array.length; i++) {
      if (array[i].length() > 2) {
        // remove quotes at start and end, if present
        if (array[i].startsWith("\"") && array[i].endsWith("\"")) {
          array[i] = array[i].substring(1, array[i].length() - 1);
        }
      }
      // make double quotes into single quotes
      array[i] = array[i].replaceAll("\"\"", "\"");
    }
  }
  
  
  public int getRowCount() {
    return rowCount;
  }
  
  
  public String getRowName(int rowIndex) {
    return rowNames[rowIndex];
  }
  
  
  public String[] getRowNames() {
    return rowNames;
  }

  
  // Find a row by its name, returns -1 if no row found. 
  // This will return the index of the first row with this name.
  // A more efficient version of this function would put row names
  // into a Hashtable (or HashMap) that would map to an integer for the row.
  public int getRowIndex(String name) {
    for (int i = 0; i < rowCount; i++) {
      if (rowNames[i].equals(name)) {
        return i;
      }
    }
    //println("No row named '" + name + "' was found");
    return -1;
  }
  
  
  // technically, this only returns the number of columns 
  // in the very first row (which will be most accurate)
  public int getColumnCount() {
    return columnCount;
  }
  
  
  public String getColumnName(int colIndex) {
    return columnNames[colIndex];
  }
  
  
  public String[] getColumnNames() {
    return columnNames;
  }


  public float getFloat(int rowIndex, int col) {
    // Remove the 'training wheels' section for greater efficiency
    // It's included here to provide more useful error messages
    
    // begin training wheels
    if ((rowIndex < 0) || (rowIndex >= data.length)) {
      throw new RuntimeException("There is no row " + rowIndex);
    }
    if ((col < 0) || (col >= data[rowIndex].length)) {
      throw new RuntimeException("Row " + rowIndex + " does not have a column " + col);
    }
    // end training wheels
    
    return data[rowIndex][col];
  }
  
  
  public boolean isValid(int row, int col) {
    if (row < 0) return false;
    if (row >= rowCount) return false;
    //if (col >= columnCount) return false;
    if (col >= data[row].length) return false;
    if (col < 0) return false;
    return !Float.isNaN(data[row][col]);
  }
  
  
  public float getColumnMin(int col) {
    float m = Float.MAX_VALUE;
    for (int i = 0; i < rowCount; i++) {
      if (!Float.isNaN(data[i][col])) {
        if (data[i][col] < m) {
          m = data[i][col];
        }
      }
    }
    return m;
  }

  
  public float getColumnMax(int col) {
    float m = -Float.MAX_VALUE;
    for (int i = 0; i < rowCount; i++) {
      if (isValid(i, col)) {
        if (data[i][col] > m) {
          m = data[i][col];
        }
      }
    }
    return m;
  }

  
  public float getRowMin(int row) {
    float m = Float.MAX_VALUE;
    for (int i = 0; i < columnCount; i++) {
      if (isValid(row, i)) {
        if (data[row][i] < m) {
          m = data[row][i];
        }
      }
    }
    return m;
  } 

  
  public float getRowMax(int row) {
    float m = -Float.MAX_VALUE;
    for (int i = 1; i < columnCount; i++) {
      if (!Float.isNaN(data[row][i])) {
        if (data[row][i] > m) {
          m = data[row][i];
        }
      }
    }
    return m;
  }
  
  
  public float getTableMin() {
    float m = Float.MAX_VALUE;
    for (int i = 0; i < rowCount; i++) {
      for (int j = 0; j < columnCount; j++) {
        if (isValid(i, j)) {
          if (data[i][j] < m) {
            m = data[i][j];
          }
        }
      }
    }
    return m;
  }

  
  public float getTableMax() {
    float m = -Float.MAX_VALUE;
    for (int i = 0; i < rowCount; i++) {
      for (int j = 0; j < columnCount; j++) {
        if (isValid(i, j)) {
          if (data[i][j] > m) {
            m = data[i][j];
          }
        }
      }
    }
    return m;
  }
}
int NUMSTEPS = 60;

class Integrator {

  float _value, _start, _target;
  int _t;
  
  final int NUM_STEPS = NUMSTEPS;
  final float STEP_SIZE = 1.0f / (float)(NUM_STEPS);
  float _normalization;

  boolean _targeting;

  Integrator(float value) {
    _value = value;
    _t = 0;
    
    // compute the normalization variable
    float total = 0.0f;
    for ( int i = 0; i <= NUM_STEPS; i++ ) {
      total += f( (float)i*STEP_SIZE );
    }
    _normalization = 1.0f/total;
  }
  
  public float f( float x ) {
   return (1.0f - (2.0f*x-1.0f)*(2.0f*x-1.0f)); 
   //return 1.0;
  }

  public void update() {
    if ( _targeting ) {
      _value += f( (float)_t*STEP_SIZE )*_normalization*( _target - _start );
      ++_t;
      
      if ( _t > NUM_STEPS ) {
        noTarget();
      }
    }    
  }

  public float value() {
    return _value; }

  public void target(float t) {
    _start = _value;
    _t = 0;
    _targeting = true;
    _target = t;
  }


  public void noTarget() {
    _targeting = false;
  }
}

class ColorIntegrator {

  int _value, _start, _target;
  int _t;
  float _time;
  
  final int NUM_STEPS = NUMSTEPS;
  final float STEP_SIZE = 1.0f / (float)(NUM_STEPS);
  float _normalization;

  boolean _targeting;

  ColorIntegrator(int value) {
    _value = value;
    _t = 0;
    _time = 0.0f;
    
    // compute the normalization variable
    float total = 0.0f;
    for ( int i = 0; i <= NUM_STEPS; i++ ) {
      total += f( (float)i*STEP_SIZE );
    }
    _normalization = 1.0f/total;
  }
  
  public float f( float x ) {
   return (1.0f - (2.0f*x-1.0f)*(2.0f*x-1.0f)); 
   //return 1.0;
  }

  public void update() {
    if ( _targeting ) {
      //_value += color(f( (float)_t*STEP_SIZE )*_normalization*( _target - _start ));
      _time += f( (float)_t*STEP_SIZE )*_normalization;
      _value = lerpColor( _start, _target, _time );
      ++_t;
      
      if ( _t > NUM_STEPS ) {
        noTarget();
      }
    }    
  }

  public int value() {
    return _value; }

  public void target(int t) {
    _start = _value;
    _t = 0;
    _targeting = true;
    _target = t;
    _time = 0.0f;
  }


  public void noTarget() {
    _targeting = false;
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "timeSeries" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
